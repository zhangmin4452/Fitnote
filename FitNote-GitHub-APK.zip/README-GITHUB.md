# FitNote：GitHub 自动打包 APK

这个版本已经加入 GitHub Actions 自动打包配置，**不需要上传 Gradle Wrapper**。

## 手机操作建议

由于手机 GitHub 网页一次只能选择一个文件/文件夹，最省事的方法是：
- 使用 GitHub 的“上传现有文件”功能逐步上传；
- 或者使用支持选择多个文件的 GitHub App/手机浏览器文件上传功能。

仓库根目录必须最终看到：
- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `.github/workflows/build-apk.yml`

其中 `.github/workflows/build-apk.yml` 会自动负责安装 Gradle 并打包。

## 打包 APK

上传完成并提交后：

1. 打开仓库的 **Actions**
2. 找到 **Build FitNote APK**
3. 如果没有自动运行，点击 **Run workflow**
4. 等待构建完成
5. 打开这次运行记录
6. 在 **Artifacts** 里下载 `FitNote-debug-apk`
7. 解压后得到 `app-debug.apk`
