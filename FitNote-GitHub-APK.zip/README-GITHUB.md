# FitNote：GitHub 自动打包 APK

这个版本已经加入 GitHub Actions 自动打包配置，**不需要上传 Gradle Wrapper**。

## 手机操作建议

由于手机 GitHub 网页一次只能选择一个文件/文件夹，最省事的方法是：
- 使用 GitHub 的“上传现有文件”功能逐步上传；
- 或者使用支持选择多个文件的 GitHub App/手机浏览器文件上传功能。

仓库根目录必须最终看到：
- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `.github/workflows/build-apk.yml`

其中 `.github/workflows/build-apk.yml` 会自动负责安装 Gradle 并打包。

## 打包 APK

上传完成并提交后：

1. 打开仓库的 **Actions**
2. 找到 **Build FitNote APK**
3. 如果没有自动运行，点击 **Run workflow**
4. 等待构建完成
5. 打开这次运行记录
6. 在 **Artifacts** 里下载 `FitNote-debug-apk`
7. 解压后得到 `app-debug.apk`


## 重要：以后更新 APK 不需要卸载

从 FitNote 2.7 开始，项目使用固定签名 `app/fitnote-release.jks`，并保持 `applicationId = "com.fitnote.app"`。

因此以后 GitHub Actions 打出的新 APK 可以直接在手机上点击安装并选择“更新/安装”，**不要先卸载旧版**。Android 更新安装会保留应用内部的 SharedPreferences 数据，包括笔记、运动打卡和热量记录。

### 第一次切换到固定签名

你当前手机里的旧版 APK 如果是之前 GitHub Actions 临时 debug 签名打出来的，新版固定签名 APK 与旧版签名不同，Android 不能直接覆盖。

第一次升级建议：

1. 打开旧版 FitNote → 首页 → 数据备份 → **导出数据**。
2. 安装 FitNote 2.7 固定签名版；如果系统提示签名不同，需要先卸载旧版。
3. 新版打开后 → 首页 → 数据备份 → **恢复数据**。
4. 以后再打包 2.7、2.8.1……都直接覆盖安装，不再卸载，数据会继续保留。

> 注意：`fitnote-release.jks` 是 APK 的签名私钥。不要把这个文件和密码公开到公共 GitHub 仓库。这个项目如果放在 GitHub，建议使用 Private Repository。


## 2.7 本次热量 AI 修复

- 手动添加食物：输入食物名称后自动调用 DeepSeek 估算常见份量热量，并自动填入 kcal；用户仍可手动修改。
- 拍照识别：改为识别整张照片中的多种主要食物，逐项返回名称、估算克重和热量。
- 使用 DeepSeek Vision 的 JSON Output，避免文本解析导致只得到一个食物。
- 图片请求使用高细节模式，并明确要求返回 `foods[]` 列表及总热量。
- 一键加入会把识别到的每一种食物分别写入今日热量记录。

## 2.8.1 热量历史记录
热量模块现在会自动保存每天的饮食记录。打开“热量”页面可以看到：
1. 今日摄入与今日饮食明细。
2. 历史热量记录，按日期倒序排列。
3. 点击历史日期展开当天早餐、午餐、晚餐、加餐及各项热量。
4. 删除历史食物后会同步保存，不影响其他日期。

### 2.8.1 DeepSeek Vision 修复
- Vision 请求关闭 thinking，避免 JSON Output 时出现空 content/非 JSON 内容。
- 增加 system JSON 强约束与更稳健的 JSON 提取。
- 相机/相册图片进入 Vision 前自动压缩到最长边 1600px、JPEG 82%，降低超大图片请求失败概率。
- 允许 grams/kcal 为数字或数字字符串。
