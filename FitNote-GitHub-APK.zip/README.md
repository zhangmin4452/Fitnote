# FitNote

Android 简约时尚的笔记 + 运动打卡 + 减脂食谱 App 第一版。

## 功能
- 首页：今日进度、快捷入口、今日饮食建议
- 笔记：查看、新建笔记
- 运动：训练项目打卡
- 食谱：减脂餐谱与热量展示
- Material 3 + 简洁卡片式 UI

## 打包 APK
用 Android Studio 打开本目录，等待 Gradle 同步，然后：
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

也可以上传到 Gitee 后使用 CI 构建 APK。
