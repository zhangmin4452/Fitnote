plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.fitnote.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fitnote.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "2.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // 固定签名：GitHub Actions 每次都是新机器，不能使用临时 debug keystore。
    // 使用项目内固定 keystore 后，同一个 applicationId 的新 APK 可以直接覆盖安装，
    // Android 会保留 SharedPreferences 等应用数据。
    signingConfigs {
        create("fitnoteStable") {
            storeFile = file("fitnote-release.jks")
            storePassword = "FitNote@2026"
            keyAlias = "fitnote"
            keyPassword = "FitNote@2026"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fitnoteStable")
        }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
