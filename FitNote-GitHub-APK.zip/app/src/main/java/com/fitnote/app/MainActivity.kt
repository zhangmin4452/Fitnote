package com.fitnote.app

import android.os.Bundle
import android.content.Context
import android.content.SharedPreferences
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFFF7F7F5)
private val Ink = Color(0xFF202320)
private val Green = Color(0xFF789B72)
private val NoteAccent = Color(0xFFD95C4F)
private val Card = Color.White

// 阅读笔记：书名 + 标题 + 正文 + 时间
// 初次打开为空，不预置任何内容。
data class Note(val book: String, val title: String, val text: String, val time: String)
data class Meal(val name: String, val kcal: Int, val desc: String)
data class Workout(val id: String, val name: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitNoteApp() }
    }
}

@Composable
fun FitNoteApp() {
    var tab by remember { mutableIntStateOf(0) }
    var notes by remember { mutableStateOf(emptyList<Note>()) }
    var workouts by remember { mutableStateOf(defaultWorkouts()) }
    var records by remember { mutableStateOf(setOf<String>()) }
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        notes = loadNotes(prefs)
        workouts = loadWorkouts(prefs)
        records = loadRecords(prefs)
    }

    fun saveAll() {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        saveNotes(prefs, notes)
        saveWorkouts(prefs, workouts)
        saveRecords(prefs, records)
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                val labels = listOf("首页", "读书", "打卡", "食谱")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.FitnessCenter, Icons.Default.Restaurant)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], null) }, label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(notes.size, records.count { it.startsWith(todayKey() + "|") }) { tab = it }
                1 -> NotesScreen(
                    notes = notes,
                    onSave = { old, new ->
                        notes = if (old == null) notes + new else notes.map { if (it == old) new else it }
                        saveAll()
                    },
                    onDelete = { note -> notes = notes - note; saveAll() }
                )
                2 -> WorkoutScreen(
                    workouts = workouts, records = records,
                    onToggle = { id ->
                        val key = todayKey() + "|" + id
                        records = if (key in records) records - key else records + key
                        saveAll()
                    },
                    onRename = { id, name ->
                        workouts = workouts.map { if (it.id == id) it.copy(name = name) else it }
                        saveAll()
                    }
                )
                3 -> MealScreen()
            }
        }
    }
}

private const val PREFS = "fitnote_data"
private const val NOTES_KEY = "notes"
private const val WORKOUTS_KEY = "workouts"
private const val RECORDS_KEY = "records"

private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

private fun defaultWorkouts() = listOf(
    Workout("dumbbell", "哑铃"),
    Workout("stairs", "上楼"),
    Workout("calf", "垫脚")
)

private fun loadNotes(p: SharedPreferences): List<Note> = p.getString(NOTES_KEY, "")!!.split("\n---\n").filter { it.isNotBlank() }.mapNotNull {
    val a = it.split("\n", limit = 4)
    if (a.size >= 4) Note(a[0], a[1], a[2], a[3]) else null
}

private fun saveNotes(p: SharedPreferences, notes: List<Note>) {
    p.edit().putString(NOTES_KEY, notes.joinToString("\n---\n") { listOf(it.book, it.title, it.text.replace("\n", " "), it.time).joinToString("\n") }).apply()
}

private fun loadWorkouts(p: SharedPreferences): List<Workout> {
    val raw = p.getString(WORKOUTS_KEY, null) ?: return defaultWorkouts()
    val result = raw.split("\n").mapNotNull { row ->
        val a = row.split("|", limit = 2)
        if (a.size == 2) Workout(a[0], a[1]) else null
    }
    return if (result.isEmpty()) defaultWorkouts() else result
}

private fun saveWorkouts(p: SharedPreferences, workouts: List<Workout>) {
    p.edit().putString(WORKOUTS_KEY, workouts.joinToString("\n") { "${it.id}|${it.name.replace("|", " ")}" }).apply()
}

private fun loadRecords(p: SharedPreferences): Set<String> = p.getStringSet(RECORDS_KEY, emptySet())?.toSet() ?: emptySet()
private fun saveRecords(p: SharedPreferences, records: Set<String>) { p.edit().putStringSet(RECORDS_KEY, records).apply() }

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
        subtitle?.let {
            Text(it, color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun HomeScreen(noteCount: Int, checkCount: Int, go: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header("FitNote", "记录 · 运动 · 阅读")
            CardBox {
                Text("今天的记录", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("读书笔记", "$noteCount")
                    Stat("今日打卡", "$checkCount 项")
                    Stat("目标", "坚持")
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionCard("写读书笔记", Icons.Default.MenuBook) { go(1) }
                ActionCard("开始打卡", Icons.Default.FitnessCenter) { go(2) }
            }
            Spacer(Modifier.height(14.dp))
            CardBox {
                Text("今日阅读", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (noteCount == 0) "还没有记录，读到好内容就记下来吧。" else "继续整理你的阅读收获。",
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column {
        Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun RowScope.ActionCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        Modifier.weight(1f).height(105.dp).clickable { onClick() },
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

/**
 * 读书笔记页面：设计参考“锤子便签”的简洁记录体验，
 * 采用大标题、搜索入口、白色便签卡片、清晰的编辑入口，
 * 但不直接复制其商标、图标或专有视觉素材。
 */
@Composable
fun NotesScreen(
    notes: List<Note>,
    onSave: (old: Note?, new: Note) -> Unit,
    onDelete: (Note) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Note?>(null) }
    var creating by remember { mutableStateOf(false) }
    val filtered = notes.filter { query.isBlank() || it.book.contains(query, true) || it.title.contains(query, true) || it.text.contains(query, true) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 18.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("读书笔记", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("像便签一样，随手记录读书心得", color = Color.Gray, fontSize = 14.sp)
                }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                singleLine = true, placeholder = { Text("搜索书名、标题或内容") },
                leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)
            )
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.MenuBook, null, tint = NoteAccent, modifier = Modifier.size(54.dp))
                        Spacer(Modifier.height(14.dp))
                        Text(if (notes.isEmpty()) "还没有读书笔记" else "没有找到相关笔记", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (notes.isEmpty()) "点击右下角 +，记录第一篇阅读心得" else "换个关键词试试看", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 14.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered) { note -> NotePaper(note, { editing = note }, { onDelete(note) }) }
                }
            }
        }
        FloatingActionButton(onClick = { creating = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = NoteAccent, contentColor = Color.White) {
            Icon(Icons.Default.Add, "新建笔记")
        }
    }

    if (creating) NoteEditorDialog(null, { creating = false }, { note -> onSave(null, note); creating = false })
    editing?.let { original ->
        NoteEditorDialog(original, { editing = null }, { note -> onSave(original, note); editing = null }, { onDelete(original); editing = null })
    }
}

@Composable
fun NotePaper(note: Note, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(8.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(NoteAccent))
            Column(Modifier.weight(1f).padding(16.dp)) {
                Text(note.book.ifBlank { "未填写书名" }, color = NoteAccent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(5.dp)); Text(note.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                if (note.text.isNotBlank()) Text(note.text, color = Color(0xFF666666), fontSize = 14.sp, maxLines = 3, modifier = Modifier.padding(top = 7.dp))
                Text(note.time, color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
            }
            IconButton(onClick = onDelete, modifier = Modifier.padding(top = 6.dp)) { Icon(Icons.Default.DeleteOutline, "删除", tint = Color.Gray) }
        }
    }
}

@Composable
fun NoteEditorDialog(original: Note?, onDismiss: () -> Unit, onSave: (Note) -> Unit, onDelete: (() -> Unit)? = null) {
    var book by remember(original) { mutableStateOf(original?.book ?: "") }
    var title by remember(original) { mutableStateOf(original?.title ?: "") }
    var text by remember(original) { mutableStateOf(original?.text ?: "") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.90f), color = Color(0xFFFFFEF9), shape = RoundedCornerShape(6.dp), shadowElevation = 12.dp) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDismiss) { Text("取消") }
                    Text(if (original == null) "新建读书笔记" else "编辑读书笔记", modifier = Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(enabled = title.isNotBlank() || text.isNotBlank(), onClick = { onSave(Note(book.trim(), title.trim().ifBlank { "无标题" }, text.trim(), original?.time ?: "刚刚")) }) { Text("保存", color = NoteAccent, fontWeight = FontWeight.Bold) }
                }
                Divider()
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    OutlinedTextField(book, { book = it }, label = { Text("书名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(title, { title = it }, label = { Text("心得标题") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(text, { text = it }, label = { Text("阅读心得") }, placeholder = { Text("写下摘录、思考和感受……") }, modifier = Modifier.fillMaxWidth().weight(1f), minLines = 12)
                    if (onDelete != null) {
                        TextButton(onClick = onDelete, modifier = Modifier.align(Alignment.End)) { Text("删除这篇笔记", color = NoteAccent) }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkoutScreen(
    workouts: List<Workout>, records: Set<String>, onToggle: (String) -> Unit, onRename: (String, String) -> Unit
) {
    val today = todayKey()
    val todayCount = workouts.count { today + "|" + it.id in records }
    val totalDays = records.mapNotNull { it.substringBefore('|').takeIf { d -> d.isNotBlank() } }.toSet().size
    var renameTarget by remember { mutableStateOf<Workout?>(null) }

    Column(Modifier.fillMaxSize()) {
        Header("运动打卡", "今天也完成一点点")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Text("累计打卡天数", color = Color.Gray, fontSize = 12.sp); Text("$totalDays 天", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green) } }
            Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Text("今日完成", color = Color.Gray, fontSize = 12.sp); Text("$todayCount / ${workouts.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
        }
        Text("每项运动的累计天数", modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp), fontWeight = FontWeight.SemiBold)
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(workouts) { w ->
                val days = records.count { it.endsWith("|${w.id}") }
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                            Text("累计 $days 天 · 今天${if (today + "|" + w.id in records) "已打卡" else "未打卡"}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        IconButton(onClick = { renameTarget = w }) { Icon(Icons.Default.Edit, "修改名称") }
                        Checkbox(w.id.let { today + "|" + it in records }, { onToggle(w.id) })
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
    renameTarget?.let { w ->
        var name by remember(w) { mutableStateOf(w.name) }
        AlertDialog(onDismissRequest = { renameTarget = null }, title = { Text("修改运动名称") }, text = { OutlinedTextField(name, { name = it }, label = { Text("名称") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onRename(w.id, name.trim()); renameTarget = null }) { Text("保存") } }, dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("取消") } })
    }
}

@Composable
fun MealScreen() {
    Header("减脂食谱", "简单、清爽、容易执行")
    val meals = listOf(
        Meal("鸡胸肉藜麦沙拉", 420, "鸡胸肉 + 藜麦 + 生菜 + 番茄"),
        Meal("虾仁蔬菜炒饭", 460, "虾仁 + 少量米饭 + 西兰花 + 鸡蛋"),
        Meal("番茄豆腐汤", 280, "番茄 + 嫩豆腐 + 菌菇 + 青菜"),
        Meal("希腊酸奶莓果碗", 320, "无糖酸奶 + 蓝莓 + 燕麦 + 坚果")
    )
    LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
        items(meals) { m ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(m.desc, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                    }
                    Text("${m.kcal} kcal", color = Green, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}
