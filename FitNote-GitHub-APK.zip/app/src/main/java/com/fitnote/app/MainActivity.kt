package com.fitnote.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFFF7F7F5)
private val Ink = Color(0xFF202320)
private val Green = Color(0xFF789B72)
private val Card = Color.White

data class Note(val title: String, val text: String, val time: String)
data class Meal(val name: String, val kcal: Int, val desc: String)
data class Workout(val name: String, val minutes: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitNoteApp() }
    }
}

@Composable
fun FitNoteApp() {
    var tab by remember { mutableIntStateOf(0) }
    var notes by remember { mutableStateOf(listOf(
        Note("今天的状态", "保持规律运动，晚餐少油少盐。", "今天 20:10"),
        Note("训练计划", "下肢 + 核心，控制在 40 分钟内。", "昨天 18:30")
    )) }
    var checked by remember { mutableStateOf(setOf("快走 30 分钟")) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                val labels = listOf("首页", "笔记", "打卡", "食谱")
                val icons = listOf(Icons.Default.Home, Icons.Default.EditNote, Icons.Default.FitnessCenter, Icons.Default.Restaurant)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], null) }, label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(notes.size, checked.size) { tab = it }
                1 -> NotesScreen(notes) { notes = notes + it }
                2 -> WorkoutScreen(checked) { checked = if (it in checked) checked - it else checked + it }
                3 -> MealScreen()
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
        subtitle?.let { Text(it, color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)) }
    }
}

@Composable
fun HomeScreen(noteCount: Int, checkCount: Int, go: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header("FitNote", "记录 · 运动 · 吃得更轻松")
            CardBox {
                Text("今天的进度", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("笔记", "$noteCount")
                    Stat("训练", "$checkCount 项")
                    Stat("目标", "减脂")
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("写笔记", Icons.Default.EditNote) { go(1) }
                ActionCard("开始打卡", Icons.Default.FitnessCenter) { go(2) }
            }
            Spacer(Modifier.height(14.dp))
            CardBox {
                Text("今日推荐", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("晚餐：鸡胸肉藜麦沙拉 · 约 420 kcal", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                Text("建议：饭后散步 20–30 分钟", color = Green, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column {
        Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun RowScope.ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.weight(1f).height(105.dp).clickable { onClick() }, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun NotesScreen(notes: List<Note>, add: (Note) -> Unit) {
    var show by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("我的笔记", "把每天的想法和状态留下来")
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 4.dp, bottom = 90.dp)
            ) {
                items(notes) { n ->
                    CardBox {
                        Text(n.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(n.text, color = Color.Gray, modifier = Modifier.padding(top = 7.dp))
                        Text(
                            n.time,
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }

        FloatingActionButton(
            onClick = { show = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = Green,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, null)
        }
    if (show) {
        var title by remember { mutableStateOf("") }
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("新建笔记") },
            text = {
                Column {
                    OutlinedTextField(title, { title = it }, label = { Text("标题") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(text, { text = it }, label = { Text("内容") }, minLines = 4)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) add(Note(title, text, "刚刚"))
                    show = false
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("取消") } }
        )
    }
}

@Composable
fun WorkoutScreen(checked: Set<String>, toggle: (String) -> Unit) {
    Header("运动打卡", "今天也完成一点点")
    val list = listOf(Workout("快走 30 分钟", 30), Workout("深蹲 3 × 15", 12), Workout("平板支撑 3 × 30 秒", 6), Workout("拉伸放松", 10))
    LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
        items(list) { w ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(w.name, fontWeight = FontWeight.SemiBold)
                        Text("${w.minutes} 分钟", color = Color.Gray, fontSize = 13.sp)
                    }
                    Checkbox(checked.contains(w.name), { toggle(w.name) })
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun MealScreen() {
    Header("减脂食谱", "简单、清爽、容易执行")
    val meals = listOf(
        Meal("鸡胸肉藜麦沙拉", 420, "鸡胸肉 + 藜麦 + 生菜 + 番茄"),
        Meal("虾仁蔬菜炒饭", 460, "虾仁 + 少量米饭 + 西兰花 + 鸡蛋"),
        Meal("番茄豆腐汤", 280, "番茄 + 嫩豆腐 + 菌菇 + 青菜"),
        Meal("希腊酸奶莓果碗", 320, "无糖酸奶 + 蓝莓 + 燕麦 + 坚果")
    )
    LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
        items(meals) { m ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(m.desc, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                    }
                    Text("${m.kcal} kcal", color = Green, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}
