package com.fitnote.app

import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import kotlinx.coroutines.delay

private val WoodBg = Color(0xFFD2AA7D)
private val Paper = Color(0xFFFFFDF7)
private val Ink = Color(0xFF29231D)
private val Brown = Color(0xFF765438)
private val Green = Color(0xFF718E68)
private val NoteAccent = Color(0xFFC9574B)
private val Muted = Color(0xFF756A60)
private val CalorieAccent = Color(0xFFE28A45)

private const val PREFS = "fitnote_data_v3"
private const val NOTES_KEY = "notes_json"
private const val WORKOUTS_KEY = "workouts"
private const val RECORDS_KEY = "records"
private const val FOODS_KEY = "foods_json"
private const val AI_KEY = "deepseek_api_key"

private data class Note(val id: String, val text: String, val time: String)
private data class Workout(val id: String, val name: String)
private data class FoodEntry(val id: String, val date: String, val type: String, val name: String, val kcal: Int, val grams: Int = 0)

class MainActivity : ComponentActivity() {
    private var cameraUri: Uri? = null
    private var onFoodImage: ((ByteArray) -> Unit)? = null
    private var pendingCameraCallback: ((ByteArray) -> Unit)? = null

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = cameraUri
        if (result.resultCode == RESULT_OK && uri != null) {
            readUriBytes(uri)
        } else {
            uri?.let { runCatching { contentResolver.delete(it, null, null) } }
            Toast.makeText(this, "拍照已取消", Toast.LENGTH_SHORT).show()
        }
    }
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { readUriBytes(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitNoteApp(this) }
    }

    fun pickFoodPhoto(callback: (ByteArray) -> Unit) {
        onFoodImage = callback
        galleryLauncher.launch("image/*")
    }

    fun takeFoodPhoto(callback: (ByteArray) -> Unit) {
        onFoodImage = callback
        launchCameraInternal()
    }

    private fun launchCameraInternal() {
        try {
            val file = File.createTempFile("fitnote_food_", ".jpg", cacheDir)
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

            val uri = cameraUri ?: throw IllegalStateException("无法创建照片 URI")
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                clipData = android.content.ClipData.newRawUri("FitNotePhoto", uri)
            }

            if (intent.resolveActivity(packageManager) == null) {
                Toast.makeText(this, "手机没有可用的相机应用", Toast.LENGTH_LONG).show()
                return
            }

            // 某些手机的系统相机会检查 URI 授权，显式授予所有可处理相机 Intent 的应用。
            packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                .forEach { info ->
                    grantUriPermission(
                        info.activityInfo.packageName,
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }

            cameraLauncher.launch(intent)
        } catch (e: SecurityException) {
            Toast.makeText(this, "相机权限或图片授权异常：${e.message ?: "请检查系统相机权限"}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "无法打开相机：${e.message ?: "未知错误"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readUriBytes(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) onFoodImage?.invoke(bytes)
        } catch (e: Exception) {
            Toast.makeText(this, "读取图片失败：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun FitNoteApp(activity: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    var notes by remember { mutableStateOf(emptyList<Note>()) }
    var workouts by remember { mutableStateOf(defaultWorkouts()) }
    var records by remember { mutableStateOf(setOf<String>()) }
    var foods by remember { mutableStateOf(emptyList<FoodEntry>()) }
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    LaunchedEffect(Unit) {
        notes = loadNotes(prefs); workouts = loadWorkouts(prefs); records = loadRecords(prefs); foods = loadFoods(prefs)
    }
    fun saveNotesNow(v: List<Note>) { notes = v; saveNotes(prefs, v) }
    fun saveAll() { saveNotes(prefs, notes); saveWorkouts(prefs, workouts); saveRecords(prefs, records); saveFoods(prefs, foods) }

    Scaffold(containerColor = WoodBg, bottomBar = {
        NavigationBar(containerColor = Paper) {
            val labels = listOf("首页", "笔记", "打卡", "热量")
            val icons = listOf(Icons.Default.Home, Icons.Default.Description, Icons.Default.FitnessCenter, Icons.Default.LocalFireDepartment)
            labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(WoodBg)) {
            when (tab) {
                0 -> HomeScreen(notes.size, records.count { it.startsWith(todayKey() + "|") }, foods.filter { it.date == todayKey() }.sumOf { it.kcal }, onNavigate = { tab = it }, prefs = prefs)
                1 -> NotesScreen(notes, { n -> saveNotesNow(notes.upsert(n)) }, { n -> saveNotesNow(notes.filterNot { it.id == n.id }) })
                2 -> WorkoutScreen(workouts, records, { id -> val k = todayKey() + "|" + id; records = if (k in records) records - k else records + k; saveAll() }, { id, name -> workouts = workouts.map { if (it.id == id) it.copy(name = name) else it }; saveAll() })
                3 -> CalorieScreen(foods, { e -> foods = foods + e; saveAll() }, { e -> foods = foods.filterNot { it.id == e.id }; saveAll() }, prefs, activity)
            }
        }
    }
}

private fun todayKey() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
private fun nowText() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
private fun defaultWorkouts() = listOf(Workout("dumbbell", "哑铃"), Workout("stairs", "上楼"), Workout("calf", "垫脚"))
private fun List<Note>.upsert(n: Note): List<Note> { val i = indexOfFirst { it.id == n.id }; return if (i < 0) this + n else toMutableList().also { it[i] = n } }

private fun loadNotes(p: SharedPreferences): List<Note> {
    p.getString(NOTES_KEY, null)?.let { raw -> try { val a = JSONArray(raw); return buildList { for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(Note(o.optString("id", UUID.randomUUID().toString()),o.optString("text"),o.optString("time"))) } } } catch (_: Exception) {} }
    val legacy = p.getString("notes_v2", "") ?: ""; if (legacy.isBlank()) return emptyList()
    val result = legacy.split(Regex("\\n---\\n(?=\\d{4}-\\d{2}-\\d{2} )")).mapNotNull { a -> val x=a.split("\\n",limit=2); if(x.size==2) Note(UUID.randomUUID().toString(),x[1],x[0]) else null }
    if(result.isNotEmpty()) saveNotes(p,result); return result
}
private fun saveNotes(p: SharedPreferences, v: List<Note>) { val a=JSONArray(); v.forEach { a.put(JSONObject().apply { put("id",it.id); put("text",it.text); put("time",it.time) }) }; p.edit().putString(NOTES_KEY,a.toString()).commit() }
private fun loadWorkouts(p: SharedPreferences): List<Workout> { val raw=p.getString(WORKOUTS_KEY,null) ?: return defaultWorkouts(); val r=raw.split("\n").mapNotNull { a->val x=a.split("|",limit=2); if(x.size==2) Workout(x[0],x[1]) else null }; return if(r.isEmpty()) defaultWorkouts() else r }
private fun saveWorkouts(p: SharedPreferences,v:List<Workout>) { p.edit().putString(WORKOUTS_KEY,v.joinToString("\n"){ "${it.id}|${it.name.replace("|"," ")}" }).commit() }
private fun loadRecords(p: SharedPreferences)=p.getStringSet(RECORDS_KEY,emptySet())?.toSet() ?: emptySet<String>()
private fun saveRecords(p: SharedPreferences,v:Set<String>) { p.edit().putStringSet(RECORDS_KEY,v).commit() }
private fun loadFoods(p: SharedPreferences):List<FoodEntry> { val raw=p.getString(FOODS_KEY,null) ?: return emptyList(); return try { val a=JSONArray(raw); buildList { for(i in 0 until a.length()){val o=a.getJSONObject(i); add(FoodEntry(o.optString("id"),o.optString("date"),o.optString("type"),o.optString("name"),o.optInt("kcal"),o.optInt("grams")))}} } catch(_:Exception){emptyList()} }
private fun saveFoods(p:SharedPreferences,v:List<FoodEntry>){val a=JSONArray();v.forEach{a.put(JSONObject().apply{put("id",it.id);put("date",it.date);put("type",it.type);put("name",it.name);put("kcal",it.kcal);put("grams",it.grams)})};p.edit().putString(FOODS_KEY,a.toString()).commit()}

@Composable private fun Header(title:String,subtitle:String?=null){Column(Modifier.padding(horizontal=20.dp,vertical=18.dp)){Text(title,fontSize=30.sp,fontWeight=FontWeight.Bold,color=Ink);subtitle?.let{Text(it,color=Muted,fontSize=14.sp,modifier=Modifier.padding(top=4.dp))}}}

@Composable
private fun HomeScreen(noteCount:Int,checkCount:Int,kcal:Int,onNavigate:(Int)->Unit,prefs:SharedPreferences){
    val activity = LocalContext.current as MainActivity
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                val o=JSONObject()
                o.put("version",2)
                o.put("notes",JSONArray(prefs.getString(NOTES_KEY,"[]")))
                o.put("workouts",prefs.getString(WORKOUTS_KEY,""))
                val rec=JSONArray(); (prefs.getStringSet(RECORDS_KEY,emptySet()) ?: emptySet()).forEach{rec.put(it)}; o.put("records",rec)
                o.put("foods",JSONArray(prefs.getString(FOODS_KEY,"[]")))
                activity.contentResolver.openOutputStream(uri)?.use{it.write(o.toString(2).toByteArray())}
                Toast.makeText(activity,"数据导出成功",Toast.LENGTH_SHORT).show()
            } catch(e:Exception){ Toast.makeText(activity,"导出失败：${e.message}",Toast.LENGTH_LONG).show() }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val raw=activity.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: ""
                if(restoreAll(prefs,raw)) Toast.makeText(activity,"数据恢复成功，请重新进入页面查看",Toast.LENGTH_SHORT).show()
                else Toast.makeText(activity,"备份文件无效",Toast.LENGTH_SHORT).show()
            } catch(e:Exception){ Toast.makeText(activity,"读取备份失败：${e.message}",Toast.LENGTH_LONG).show() }
        }
    }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=30.dp)){item{
        Header("FitNote","记录 · 运动 · 阅读 · 热量")
        CardBox{Text("今天的记录",fontWeight=FontWeight.SemiBold,fontSize=18.sp);Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Stat("读书笔记","$noteCount");Stat("今日打卡","$checkCount 项");Stat("今日热量","$kcal kcal")}}
        Spacer(Modifier.height(14.dp));Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){ActionCard("写笔记",Icons.Default.Description){onNavigate(1)};ActionCard("开始打卡",Icons.Default.FitnessCenter){onNavigate(2)}}
        Spacer(Modifier.height(14.dp));CardBox{Text("每日热量",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("拍照识别食物、手动记录，管理每天摄入。",color=Muted,modifier=Modifier.padding(top=8.dp));Text("去记录 →",color=Brown,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=10.dp).clickable{onNavigate(3)})}
        Spacer(Modifier.height(14.dp));CardBox{Text("数据备份",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("导出后即使卸载 App，也可以在重新安装后恢复。",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=6.dp));Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick={exportLauncher.launch("FitNote备份-${todayKey()}.json")},colors=ButtonDefaults.buttonColors(containerColor=Brown)){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(5.dp));Text("导出数据")};OutlinedButton(onClick={importLauncher.launch("application/json")}){Icon(Icons.Default.FileOpen,null);Spacer(Modifier.width(5.dp));Text("恢复数据")}}}
    }}
}

@Composable private fun Stat(label:String,value:String){Column{Text(value,fontSize=19.sp,fontWeight=FontWeight.Bold,color=Ink);Text(label,color=Muted,fontSize=12.sp)}}
@Composable fun RowScope.ActionCard(title:String,icon:ImageVector,onClick:()->Unit){Card(Modifier.weight(1f).height(105.dp).clickable{onClick()},shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.SpaceBetween){Icon(icon,null,tint=Green,modifier=Modifier.size(28.dp));Text(title,fontWeight=FontWeight.SemiBold,color=Ink)}}}
@Composable private fun CardBox(content:@Composable ColumnScope.()->Unit){Card(Modifier.padding(horizontal=20.dp).fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(18.dp),content=content)}}

@Composable
private fun NotesScreen(
    notes: List<Note>,
    onUpsert: (Note) -> Unit,
    onDelete: (Note) -> Unit
) {
    var editingId by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val editingNote = notes.firstOrNull { it.id == editingId }

    if (editingId != null) {
        NoteEditorScreen(
            original = editingNote,
            noteId = editingId!!,
            onBack = { editingId = null },
            onUpsert = onUpsert,
            onDelete = if (editingNote != null) {
                {
                    onDelete(editingNote)
                    editingId = null
                }
            } else {
                null
            }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("笔记", "像便签一样，随手记下读书心得")

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                singleLine = true,
                placeholder = { Text("搜索笔记内容") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Paper,
                    focusedContainerColor = Paper
                )
            )

            val filtered = notes.filter {
                query.isBlank() || it.text.contains(query, ignoreCase = true)
            }

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Description,
                            null,
                            tint = NoteAccent,
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("还没有笔记", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "点击右下角 +，直接开始写",
                            color = Muted,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(top = 14.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        NotePaper(note) { editingId = note.id }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { editingId = UUID.randomUUID().toString() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = NoteAccent,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, "新建笔记")
        }
    }
}

@Composable private fun NotePaper(note:Note,onClick:()->Unit){Card(Modifier.padding(horizontal=20.dp).fillMaxWidth().clickable{onClick()},shape=RoundedCornerShape(7.dp),elevation=CardDefaults.cardElevation(3.dp),colors=CardDefaults.cardColors(containerColor=Paper)){Row(Modifier.fillMaxWidth()){Box(Modifier.width(5.dp).height(105.dp).background(NoteAccent));Column(Modifier.weight(1f).padding(16.dp)){Text(note.text.ifBlank{"空白笔记"},color=Ink,fontSize=17.sp,maxLines=4,overflow=TextOverflow.Ellipsis);Text(note.time,color=Color(0xFF9A8F83),fontSize=11.sp,modifier=Modifier.padding(top=10.dp))};Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFAAA096),modifier=Modifier.align(Alignment.CenterVertically).padding(end=10.dp))}}}
@Composable private fun NoteEditorScreen(original:Note?,noteId:String,onBack:()->Unit,onUpsert:(Note)->Unit,onDelete:(()->Unit)?){var text by remember(noteId){mutableStateOf(original?.text ?: "")};var showDelete by remember{mutableStateOf(false)};var lastSaved by remember(noteId){mutableStateOf(original?.text ?: "")};val time=remember(noteId){original?.time ?: nowText()};LaunchedEffect(text){if(text!=lastSaved){onUpsert(Note(noteId,text,time));lastSaved=text}};BackHandler{onUpsert(Note(noteId,text,time));onBack()};Box(Modifier.fillMaxSize().background(WoodBg)){Column(Modifier.fillMaxSize().padding(horizontal=14.dp)){Row(Modifier.fillMaxWidth().padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically){IconButton({onUpsert(Note(noteId,text,time));onBack()}){Icon(Icons.Default.ArrowBack,"返回",tint=Ink)};Text(if(original==null)"新建笔记" else "编辑笔记",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.weight(1f));if(onDelete!=null)IconButton({showDelete=true}){Icon(Icons.Default.DeleteOutline,"删除",tint=NoteAccent)};TextButton(onClick={onUpsert(Note(noteId,text,time));lastSaved=text}){Text("保存",color=NoteAccent,fontWeight=FontWeight.Bold)}};Surface(Modifier.fillMaxSize().padding(bottom=10.dp),color=Paper,shape=RoundedCornerShape(4.dp),shadowElevation=5.dp){OutlinedTextField(text,{text=it},Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=14.dp),placeholder={Text("写下读书心得、摘录和思考……",color=Color(0xFFB9AEA3))},colors=OutlinedTextFieldDefaults.colors(unfocusedBorderColor=Color.Transparent,focusedBorderColor=Color.Transparent,cursorColor=NoteAccent),textStyle=LocalTextStyle.current.copy(fontSize=18.sp,lineHeight=30.sp,color=Ink))}}};if(showDelete)AlertDialog(onDismissRequest={showDelete=false},title={Text("删除这篇笔记？")},text={Text("删除后无法恢复。")},confirmButton={TextButton({showDelete=false;onDelete?.invoke()}){Text("删除",color=NoteAccent)}},dismissButton={TextButton({showDelete=false}){Text("取消")}})}

@Composable private fun WorkoutScreen(workouts:List<Workout>,records:Set<String>,onToggle:(String)->Unit,onRename:(String,String)->Unit){val today=todayKey();val todayCount=workouts.count{"$today|${it.id}" in records};val totalDays=records.mapNotNull{it.substringBefore('|').takeIf{d->d.isNotBlank()}}.toSet().size;var target by remember{mutableStateOf<Workout?>(null)};Column(Modifier.fillMaxSize()){Header("运动打卡","哑铃 · 上楼 · 垫脚");Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("累计打卡天数","$totalDays 天",Green);StatCard("今日完成","$todayCount / ${workouts.size}",Brown)};Text("每项运动累计天数",modifier=Modifier.padding(start=20.dp,top=18.dp,bottom=8.dp),fontWeight=FontWeight.SemiBold,color=Ink);LazyColumn(contentPadding=PaddingValues(bottom=90.dp)){items(workouts,key={it.id}){w->val days=records.count{it.endsWith("|${w.id}")};CardBox{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(w.name,fontWeight=FontWeight.SemiBold,fontSize=17.sp,color=Ink);Text("累计 $days 天 · 今天${if("$today|${w.id}" in records)"已打卡" else "未打卡"}",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))};IconButton({target=w}){Icon(Icons.Default.Edit,"修改名称",tint=Brown)};Checkbox("$today|${w.id}" in records,{onToggle(w.id)})}};Spacer(Modifier.height(10.dp))}}};target?.let{w->var name by remember(w){mutableStateOf(w.name)};AlertDialog(onDismissRequest={target=null},title={Text("修改运动名称")},text={OutlinedTextField(name,{name=it},label={Text("名称")},singleLine=true)},confirmButton={TextButton({if(name.isNotBlank())onRename(w.id,name.trim());target=null}){Text("保存")}},dismissButton={TextButton({target=null}){Text("取消")}})}}
@Composable private fun RowScope.StatCard(label:String,value:String,tint:Color){Card(Modifier.weight(1f),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(15.dp)){Text(label,color=Muted,fontSize=12.sp);Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=tint)}}}

@Composable
private fun CalorieScreen(
    foods: List<FoodEntry>,
    onAdd: (FoodEntry) -> Unit,
    onDelete: (FoodEntry) -> Unit,
    prefs: SharedPreferences,
    activity: MainActivity
) {
    val today = todayKey()
    val target = 1800
    val todayFoods = foods.filter { it.date == today }
    val todayTotal = todayFoods.sumOf { it.kcal }
    var showAdd by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var expandedDate by remember { mutableStateOf<String?>(null) }

    // 每一天都有独立的热量记录；历史数据来自同一个 foods_json，因此升级版本不会丢失。
    val historyDates = foods.map { it.date }
        .filter { it.isNotBlank() && it != today }
        .distinct()
        .sortedDescending()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Header("每日热量", "记录早餐 · 午餐 · 晚餐 · 加餐")
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("今日摄入", color = Muted, fontSize = 13.sp)
                        Text("$todayTotal kcal", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = CalorieAccent)
                        Text("目标 $target kcal", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.LocalFireDepartment, null, tint = CalorieAccent, modifier = Modifier.size(52.dp))
                }
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { (todayTotal.toFloat() / target).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = CalorieAccent,
                    trackColor = Color(0xFFEADBC9)
                )
            }

            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    { showAi = true },
                    Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Brown),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.CameraAlt, null)
                    Spacer(Modifier.width(4.dp))
                    Text("拍照识别")
                }
                OutlinedButton(
                    { showAdd = true },
                    Modifier.weight(1f),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(4.dp))
                    Text("手动添加")
                }
            }
            TextButton(
                { showKey = true },
                Modifier.padding(start = 16.dp)
            ) {
                Icon(Icons.Default.Key, null)
                Spacer(Modifier.width(4.dp))
                Text(if (prefs.getString(AI_KEY, "").isNullOrBlank()) "设置 AI Key" else "AI 已配置")
            }

            Text(
                "今天的饮食",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(start = 20.dp, top = 4.dp, bottom = 6.dp)
            )
        }

        if (todayFoods.isEmpty()) {
            item {
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalFireDepartment, null, tint = CalorieAccent, modifier = Modifier.size(38.dp))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("今天还没有热量记录", fontWeight = FontWeight.SemiBold)
                            Text("拍照或手动添加早餐、午餐、晚餐", color = Muted, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            items(listOf("早餐", "午餐", "晚餐", "加餐")) { type ->
                val list = todayFoods.filter { it.type == type }
                if (list.isNotEmpty()) {
                    Text(
                        type,
                        color = Brown,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 20.dp, top = 10.dp, bottom = 6.dp)
                    )
                    list.forEach { food ->
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(food.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Text(
                                        (if (food.grams > 0) "约 ${food.grams}g · " else "") + "${food.kcal} kcal",
                                        color = Muted,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                                IconButton({ onDelete(food) }) {
                                    Icon(Icons.Default.DeleteOutline, "删除", tint = NoteAccent)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(12.dp))
            Text(
                "历史热量记录",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp)
            )
            Text(
                if (historyDates.isEmpty()) "以后每天的热量都会自动保存在这里" else "共 ${historyDates.size} 天有热量记录 · 点击日期查看当天详情",
                color = Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
            )
        }

        if (historyDates.isEmpty()) {
            item {
                CardBox {
                    Text("还没有历史记录", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("明天开始记录后，这里会自动出现历史热量。", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
                }
            }
        } else {
            items(historyDates, key = { it }) { date ->
                val dateFoods = foods.filter { it.date == date }
                val dateTotal = dateFoods.sumOf { it.kcal }
                val expanded = expandedDate == date
                CardBox {
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            expandedDate = if (expanded) null else date
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(formatHistoryDate(date), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("${dateFoods.size} 条记录 · $dateTotal kcal", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        Icon(
                            if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            "展开",
                            tint = Brown
                        )
                    }

                    if (expanded) {
                        Spacer(Modifier.height(10.dp))
                        listOf("早餐", "午餐", "晚餐", "加餐").forEach { type ->
                            val list = dateFoods.filter { it.type == type }
                            if (list.isNotEmpty()) {
                                Text(type, color = Brown, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 5.dp))
                                list.forEach { food ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text(food.name, color = Ink, fontSize = 15.sp)
                                            if (food.grams > 0) Text("约 ${food.grams}g", color = Muted, fontSize = 12.sp)
                                        }
                                        Text("${food.kcal} kcal", color = CalorieAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        IconButton({ onDelete(food) }, modifier = Modifier.size(34.dp)) {
                                            Icon(Icons.Default.DeleteOutline, "删除", tint = NoteAccent, modifier = Modifier.size(19.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showAdd) AddFoodDialog({ showAdd = false }) { type, name, kcal ->
        onAdd(FoodEntry(UUID.randomUUID().toString(), today, type, name, kcal))
        showAdd = false
    }
    if (showAi) AiFoodDialog(activity, prefs, { showAi = false }) { type, items ->
        items.forEach { item ->
            onAdd(FoodEntry(UUID.randomUUID().toString(), today, type, item.name, item.kcal, item.grams))
        }
        showAi = false
    }
    if (showKey) AiKeyDialog(prefs) { showKey = false }
}

private fun formatHistoryDate(date: String): String {
    return try {
        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(date)
        if (parsed != null) SimpleDateFormat("yyyy年MM月dd日 · EEEE", Locale.CHINA).format(parsed) else date
    } catch (_: Exception) {
        date
    }
}

@Composable
private fun AddFoodDialog(onDismiss:()->Unit,onAdd:(String,String,Int)->Unit){
    var type by remember{mutableStateOf("早餐")}
    var name by remember{mutableStateOf("")}
    var kcal by remember{mutableStateOf("")}
    var estimating by remember{mutableStateOf(false)}
    var estimateError by remember{mutableStateOf("")}
    var userEditedKcal by remember{mutableStateOf(false)}
    val types=listOf("早餐","午餐","晚餐","加餐")
    val context=LocalContext.current
    val prefs=remember(context){context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)}
    val key=prefs.getString(AI_KEY,"") ?: ""
    val latestUserEditedKcal=rememberUpdatedState(userEditedKcal)

    LaunchedEffect(name,key){
        if(name.trim().length < 2 || key.isBlank()) return@LaunchedEffect
        delay(750)
        estimating=true
        estimateError=""
        estimateFoodCaloriesWithDeepSeek(name.trim(),key){value,error->
            estimating=false
            if(error==null && !latestUserEditedKcal.value){ kcal=value.toString() }
            else if(error!=null) estimateError=error
        }
    }

    AlertDialog(onDismissRequest=onDismiss,title={Text("添加食物")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){types.forEach{t->FilterChip(type==t,{type=t},{Text(t,fontSize=12.sp)})}}
            OutlinedTextField(name,{name=it;userEditedKcal=false},label={Text("食物名称")},singleLine=true,
                supportingText={
                    when {
                        estimating -> Text("DeepSeek 正在估算热量…",color=Brown)
                        estimateError.isNotBlank() -> Text(estimateError,color=NoteAccent)
                        key.isBlank() -> Text("请先设置 AI Key，输入食物后可自动估算",color=Muted)
                        else -> Text("输入食物名称后自动估算，可手动修改",color=Muted)
                    }
                })
            OutlinedTextField(kcal,{kcal=it.filter(Char::isDigit);userEditedKcal=true},label={Text("热量 kcal")},singleLine=true)
        }
    },confirmButton={TextButton(enabled=name.isNotBlank()&&kcal.toIntOrNull()!=null,onClick={onAdd(type,name.trim(),kcal.toInt())}){Text("加入")}},dismissButton={TextButton(onDismiss){Text("取消")}})
}

@Composable
private fun AiKeyDialog(prefs:SharedPreferences,onDismiss:()->Unit){var key by remember{mutableStateOf(prefs.getString(AI_KEY,"") ?: "")};AlertDialog(onDismissRequest=onDismiss,title={Text("AI 食物识别")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("使用 DeepSeek Vision 识别食物。请填入你自己的 API Key，Key 只保存在本机。",color=Muted,fontSize=13.sp);OutlinedTextField(key,{key=it},label={Text("DeepSeek API Key")},singleLine=true)}} ,confirmButton={TextButton({prefs.edit().putString(AI_KEY,key.trim()).apply();onDismiss()}){Text("保存")}},dismissButton={TextButton(onDismiss){Text("取消")}})}

data class AiFoodItem(val name:String,val grams:Int,val kcal:Int)

data class AiFoodResult(val foods:List<AiFoodItem>,val totalKcal:Int)

@Composable
private fun AiFoodDialog(activity:MainActivity,prefs:SharedPreferences,onDismiss:()->Unit,onAdd:(String,List<AiFoodItem>)->Unit){
    var type by remember{mutableStateOf("早餐")}
    var loading by remember{mutableStateOf(false)}
    var result by remember{mutableStateOf<AiFoodResult?>(null)}
    var error by remember{mutableStateOf("")}
    val key=prefs.getString(AI_KEY,"") ?: ""
    val types=listOf("早餐","午餐","晚餐","加餐")
    fun analyze(bytes:ByteArray){
        if(key.isBlank()){error="请先设置 DeepSeek API Key";return}
        loading=true;error="";result=null
        analyzeFoodWithDeepSeek(bytes,key){r,e->loading=false;result=r;error=e ?: ""}
    }
    AlertDialog(onDismissRequest={if(!loading)onDismiss()},title={Text("AI 识别整盘食物")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("拍一张整盘食物，AI 会尽量识别所有主要食物，并分别估算重量和热量。",color=Muted,fontSize=13.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){types.forEach{t->FilterChip(type==t,{type=t},{Text(t,fontSize=12.sp)} )}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button({activity.takeFoodPhoto(::analyze)},Modifier.weight(1f),enabled=!loading){Icon(Icons.Default.CameraAlt,null);Spacer(Modifier.width(4.dp));Text("拍照")}
                OutlinedButton({activity.pickFoodPhoto(::analyze)},Modifier.weight(1f),enabled=!loading){Icon(Icons.Default.PhotoLibrary,null);Spacer(Modifier.width(4.dp));Text("相册")}
            }
            if(loading){LinearProgressIndicator(Modifier.fillMaxWidth());Text("AI 正在识别整盘食物…",color=Muted)}
            if(error.isNotBlank())Text(error,color=NoteAccent)
            result?.let{r->
                HorizontalDivider()
                Text("共识别 ${r.foods.size} 种食物",fontWeight=FontWeight.Bold,fontSize=17.sp)
                LazyColumn(modifier=Modifier.heightIn(max=260.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                    items(r.foods){item->
                        Card(colors=CardDefaults.cardColors(containerColor=Paper)){
                            Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                                Column(Modifier.weight(1f)){Text(item.name,fontWeight=FontWeight.SemiBold);Text("约 ${item.grams} g",color=Muted,fontSize=12.sp)}
                                Text("${item.kcal} kcal",color=CalorieAccent,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                }
                Text("合计：${r.totalKcal} kcal",color=CalorieAccent,fontWeight=FontWeight.Bold,fontSize=18.sp)
            }
        }
    },confirmButton={if(result!=null && result!!.foods.isNotEmpty())TextButton({onAdd(type,result!!.foods)}){Text("全部加入今日热量",color=Brown,fontWeight=FontWeight.Bold)}},dismissButton={TextButton({if(!loading)onDismiss()}){Text("关闭")}})
}

private fun estimateFoodCaloriesWithDeepSeek(foodName:String,apiKey:String,callback:(Int,String?)->Unit){
    Executors.newSingleThreadExecutor().execute{
        try{
            val prompt="""
你是食物热量估算助手。根据用户输入的食物名称，估算常见一份的热量。
用户输入：$foodName
请只返回 JSON，不要 Markdown：
{"kcal":70,"grams":50,"unit":"克"}
规则：kcal 必须是整数；grams 是常见一份对应的克数；如果名称有歧义，按最常见的食用方式估算。
""".trimIndent()
            val body=JSONObject().apply{
                put("model","deepseek-v4-flash")
                put("messages",JSONArray()
                    .put(JSONObject().apply{put("role","system");put("content","你是可靠的食物热量估算助手，只输出 JSON。")})
                    .put(JSONObject().apply{put("role","user");put("content",prompt)}))
                put("response_format",JSONObject().put("type","json_object"))
                put("max_tokens",300)
            }
            val c=java.net.URL("https://api.deepseek.com/chat/completions").openConnection() as java.net.HttpURLConnection
            c.requestMethod="POST";c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer $apiKey");c.connectTimeout=20000;c.readTimeout=30000;c.doOutput=true
            c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
            val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val raw=stream?.bufferedReader()?.use{it.readText()} ?: ""
            if(code !in 200..299)throw Exception("DeepSeek 接口错误 $code：${raw.take(250)}")
            val text=JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            val o=JSONObject(text.trim());val kcal=o.optInt("kcal",0);if(kcal<=0)throw Exception("AI 没有返回有效热量")
            Handler(Looper.getMainLooper()).post{callback(kcal,null)}
        }catch(e:Exception){Handler(Looper.getMainLooper()).post{callback(0,"自动估算失败，可手动输入热量")}}
    }
}

private fun analyzeFoodWithDeepSeek(imageBytes:ByteArray,apiKey:String,callback:(AiFoodResult?,String?)->Unit){
    Executors.newSingleThreadExecutor().execute{
        try{
            val mime=when{
                imageBytes.size>=2&&imageBytes[0].toInt()==0xFF&&imageBytes[1].toInt()==0xD8 -> "image/jpeg"
                imageBytes.size>=8&&imageBytes[0].toInt()==0x89&&imageBytes[1].toInt()==0x50 -> "image/png"
                imageBytes.size>=6&&String(imageBytes,0,6,Charsets.US_ASCII).startsWith("GIF") -> "image/gif"
                else -> "image/jpeg"
            }
            val base64=Base64.encodeToString(imageBytes,Base64.NO_WRAP)
            val prompt="""
你是专业的食物识别和热量估算助手。
请仔细分析整张食物照片，识别图片中所有清晰可见的主要食物，不要只返回一种。
例如一盘照片里同时有米饭、鸡蛋、青菜、鸡胸肉，必须分别返回 4 项。
把明显不同的食物分开；如果同一种食物出现多份可以合并。
对每一种食物分别估算可食用重量（克）和热量（kcal）。
不要把餐具、桌面、饮料包装等当成食物。
请只返回 JSON，不要 Markdown，格式必须是：
{"foods":[{"name":"米饭","grams":200,"kcal":232},{"name":"鸡蛋","grams":50,"kcal":70}],"total_kcal":302}
要求：foods 至少返回所有能确认的主要食物；kcal 和 grams 必须是整数；total_kcal 等于 foods 中 kcal 之和；无法精确判断时按常见熟食份量合理估算。
""".trimIndent()
            val content=JSONArray()
                .put(JSONObject().put("type","text").put("text",prompt))
                .put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:$mime;base64,$base64").put("detail","high")))
            val body=JSONObject().apply{
                put("model","deepseek-v4-flash-vision-exp")
                put("messages",JSONArray().put(JSONObject().apply{put("role","user");put("content",content)}))
                put("response_format",JSONObject().put("type","json_object"))
                put("max_tokens",1200)
            }
            val c=java.net.URL("https://api.deepseek.com/chat/completions").openConnection() as java.net.HttpURLConnection
            c.requestMethod="POST";c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer $apiKey");c.connectTimeout=30000;c.readTimeout=90000;c.doOutput=true
            c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
            val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val raw=stream?.bufferedReader()?.use{it.readText()} ?: ""
            if(code !in 200..299)throw Exception("DeepSeek 接口错误 $code：${raw.take(300)}")
            val text=JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            val cleaned=text.replace("```json","").replace("```","").trim()
            val jsonStart=cleaned.indexOf('{');val jsonEnd=cleaned.lastIndexOf('}')
            if(jsonStart<0||jsonEnd<=jsonStart)throw Exception("AI 返回格式不是 JSON")
            val o=JSONObject(cleaned.substring(jsonStart,jsonEnd+1))
            val a=o.optJSONArray("foods") ?: throw Exception("AI 没有返回食物列表")
            val foods=buildList{
                for(i in 0 until a.length()){
                    val item=a.getJSONObject(i)
                    val name=item.optString("name").trim();val grams=item.optInt("grams",0);val kcal=item.optInt("kcal",0)
                    if(name.isNotBlank() && kcal>0)add(AiFoodItem(name,grams.coerceAtLeast(0),kcal))
                }
            }
            if(foods.isEmpty())throw Exception("没有识别到有效食物")
            val total=o.optInt("total_kcal",foods.sumOf{it.kcal}).takeIf{it>0} ?: foods.sumOf{it.kcal}
            Handler(Looper.getMainLooper()).post{callback(AiFoodResult(foods,total),null)}
        }catch(e:Exception){Handler(Looper.getMainLooper()).post{callback(null,"识别失败：${e.message ?: "未知错误"}")}}
    }
}

private fun restoreAll(p:SharedPreferences,raw:String):Boolean{try{val o=JSONObject(raw);if(!o.has("version"))return false;val e=p.edit();e.putString(NOTES_KEY,o.optJSONArray("notes")?.toString() ?: "[]");e.putString(WORKOUTS_KEY,o.optString("workouts",""));val rec=o.optJSONArray("records");if(rec!=null){val set=mutableSetOf<String>();for(i in 0 until rec.length())set.add(rec.getString(i));e.putStringSet(RECORDS_KEY,set)};e.putString(FOODS_KEY,o.optJSONArray("foods")?.toString() ?: "[]");e.commit();return true}catch(_:Exception){return false}}
