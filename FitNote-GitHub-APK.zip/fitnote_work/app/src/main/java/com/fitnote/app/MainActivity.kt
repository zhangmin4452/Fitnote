package com.fitnote.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val WoodBg = Color(0xFFD2AA7D)
private val Paper = Color(0xFFFFFDF7)
private val Ink = Color(0xFF29231D)
private val Brown = Color(0xFF765438)
private val Green = Color(0xFF718E68)
private val NoteAccent = Color(0xFFC9574B)
private val Muted = Color(0xFF756A60)

data class Note(val text: String, val time: String)
data class Meal(val type: String, val name: String, val kcal: Int, val desc: String)
data class Workout(val id: String, val name: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitNoteApp() }
    }
}

@Composable
fun FitNoteApp() {
    var tab by remember { mutableIntStateOf(0) }
    var notes by remember { mutableStateOf(emptyList<Note>()) }
    var workouts by remember { mutableStateOf(defaultWorkouts()) }
    var records by remember { mutableStateOf(setOf<String>()) }
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        notes = loadNotes(prefs)
        workouts = loadWorkouts(prefs)
        records = loadRecords(prefs)
    }

    fun saveAll() {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        saveNotes(prefs, notes)
        saveWorkouts(prefs, workouts)
        saveRecords(prefs, records)
    }

    Scaffold(
        containerColor = WoodBg,
        bottomBar = {
            NavigationBar(containerColor = Paper) {
                val labels = listOf("首页", "笔记", "打卡", "食谱")
                val icons = listOf(Icons.Default.Home, Icons.Default.Description, Icons.Default.FitnessCenter, Icons.Default.Restaurant)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], null) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(WoodBg)) {
            when (tab) {
                0 -> HomeScreen(notes.size, records.count { it.startsWith(todayKey() + "|") }) { tab = it }
                1 -> NotesScreen(
                    notes = notes,
                    onSave = { old, new ->
                        notes = if (old == null) notes + new else notes.map { if (it == old) new else it }
                        saveAll()
                    },
                    onDelete = { note -> notes = notes - note; saveAll() }
                )
                2 -> WorkoutScreen(
                    workouts = workouts,
                    records = records,
                    onToggle = { id ->
                        val key = todayKey() + "|" + id
                        records = if (key in records) records - key else records + key
                        saveAll()
                    },
                    onRename = { id, name ->
                        workouts = workouts.map { if (it.id == id) it.copy(name = name) else it }
                        saveAll()
                    }
                )
                3 -> MealScreen()
            }
        }
    }
}

private const val PREFS = "fitnote_data"
private const val NOTES_KEY = "notes_v2"
private const val WORKOUTS_KEY = "workouts"
private const val RECORDS_KEY = "records"

private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
private fun nowText(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

private fun defaultWorkouts() = listOf(
    Workout("dumbbell", "哑铃"),
    Workout("stairs", "上楼"),
    Workout("calf", "垫脚")
)

private fun loadNotes(p: SharedPreferences): List<Note> = p.getString(NOTES_KEY, "")!!.split("\n---\n")
    .filter { it.isNotBlank() }
    .mapNotNull {
        val a = it.split("\n", limit = 2)
        if (a.size == 2) Note(a[0], a[1]) else null
    }

private fun saveNotes(p: SharedPreferences, notes: List<Note>) {
    p.edit().putString(NOTES_KEY, notes.joinToString("\n---\n") { "${it.time}\n${it.text}" }).apply()
}

private fun loadWorkouts(p: SharedPreferences): List<Workout> {
    val raw = p.getString(WORKOUTS_KEY, null) ?: return defaultWorkouts()
    val result = raw.split("\n").mapNotNull { row ->
        val a = row.split("|", limit = 2)
        if (a.size == 2) Workout(a[0], a[1]) else null
    }
    return if (result.isEmpty()) defaultWorkouts() else result
}

private fun saveWorkouts(p: SharedPreferences, workouts: List<Workout>) {
    p.edit().putString(WORKOUTS_KEY, workouts.joinToString("\n") { "${it.id}|${it.name.replace("|", " ")}" }).apply()
}

private fun loadRecords(p: SharedPreferences): Set<String> = p.getStringSet(RECORDS_KEY, emptySet())?.toSet() ?: emptySet()
private fun saveRecords(p: SharedPreferences, records: Set<String>) { p.edit().putStringSet(RECORDS_KEY, records).apply() }

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
        subtitle?.let { Text(it, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)) }
    }
}

@Composable
fun HomeScreen(noteCount: Int, checkCount: Int, go: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Header("FitNote", "记录 · 运动 · 阅读")
            CardBox {
                Text("今天的记录", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("读书笔记", "$noteCount")
                    Stat("今日打卡", "$checkCount 项")
                    Stat("状态", "坚持")
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("写笔记", Icons.Default.Description) { go(1) }
                ActionCard("开始打卡", Icons.Default.FitnessCenter) { go(2) }
            }
            Spacer(Modifier.height(14.dp))
            CardBox {
                Text("早餐 · 午餐 · 晚餐", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("打开食谱，看看今天适合吃什么。", color = Muted, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(10.dp))
                Text("查看饮食建议 →", color = Brown, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { go(3) })
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column { Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink); Text(label, color = Muted, fontSize = 12.sp) }
}

@Composable
fun RowScope.ActionCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Card(Modifier.weight(1f).height(105.dp).clickable { onClick() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Paper)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.SemiBold, color = Ink)
        }
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Paper)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun NotesScreen(notes: List<Note>, onSave: (Note?, Note) -> Unit, onDelete: (Note) -> Unit) {
    var editing by remember { mutableStateOf<Note?>(null) }
    var isCreating by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    if (isCreating || editing != null) {
        NoteEditorScreen(
            original = editing,
            onBack = { isCreating = false; editing = null },
            onSave = { note -> onSave(editing, note); isCreating = false; editing = null },
            onDelete = if (editing != null) ({ onDelete(editing!!); isCreating = false; editing = null }) else null
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("笔记", "像便签一样，随手记下想法")
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                singleLine = true,
                placeholder = { Text("搜索笔记内容") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Paper, focusedContainerColor = Paper)
            )
            val filtered = notes.filter { query.isBlank() || it.text.contains(query, true) }
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Description, null, tint = NoteAccent, modifier = Modifier.size(52.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("还没有笔记", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("点击右下角 +，直接开始写", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(top = 14.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered) { note -> NotePaper(note) { editing = note } }
                }
            }
        }
        FloatingActionButton(onClick = { isCreating = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = NoteAccent, contentColor = Color.White) {
            Icon(Icons.Default.Add, "新建笔记")
        }
    }
}

@Composable
fun NotePaper(note: Note, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(7.dp), elevation = CardDefaults.cardElevation(3.dp), colors = CardDefaults.cardColors(containerColor = Paper)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).height(105.dp).background(NoteAccent))
            Column(Modifier.weight(1f).padding(16.dp)) {
                Text(note.text.ifBlank { "空白笔记" }, color = Ink, fontSize = 17.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                Text(note.time, color = Color(0xFF9A8F83), fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFAAA096), modifier = Modifier.align(Alignment.CenterVertically).padding(end = 10.dp))
        }
    }
}

@Composable
fun NoteEditorScreen(original: Note?, onBack: () -> Unit, onSave: (Note) -> Unit, onDelete: (() -> Unit)?) {
    var text by remember(original) { mutableStateOf(original?.text ?: "") }
    var showDelete by remember { mutableStateOf(false) }
    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(WoodBg)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回", tint = Ink) }
                Text(if (original == null) "新建笔记" else "编辑笔记", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                if (onDelete != null) IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.DeleteOutline, "删除", tint = NoteAccent) }
                TextButton(enabled = text.isNotBlank(), onClick = { onSave(Note(text.trim(), original?.time ?: nowText())) }) {
                    Text("保存", color = NoteAccent, fontWeight = FontWeight.Bold)
                }
            }
            Surface(Modifier.fillMaxSize().padding(bottom = 10.dp), color = Paper, shape = RoundedCornerShape(4.dp), shadowElevation = 5.dp) {
                Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp)) {
                    Text(text = if (original == null) "今天想记录什么？" else "继续编辑这篇笔记", color = Color(0xFFB0A59A), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().fillMaxHeight(),
                        placeholder = { Text("写下读书心得、摘录和思考……", color = Color(0xFFB9AEA3)) },
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent, cursorColor = NoteAccent),
                        textStyle = LocalTextStyle.current.copy(fontSize = 18.sp, lineHeight = 30.sp, color = Ink)
                    )
                }
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("删除这篇笔记？") },
            text = { Text("删除后无法恢复。") },
            confirmButton = { TextButton(onClick = { showDelete = false; onDelete?.invoke() }) { Text("删除", color = NoteAccent) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("取消") } }
        )
    }
}

@Composable
fun WorkoutScreen(workouts: List<Workout>, records: Set<String>, onToggle: (String) -> Unit, onRename: (String, String) -> Unit) {
    val today = todayKey()
    val todayCount = workouts.count { "$today|${it.id}" in records }
    val totalDays = records.mapNotNull { it.substringBefore('|').takeIf { d -> d.isNotBlank() } }.toSet().size
    var renameTarget by remember { mutableStateOf<Workout?>(null) }

    Column(Modifier.fillMaxSize()) {
        Header("运动打卡", "哑铃 · 上楼 · 垫脚")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("累计打卡天数", "$totalDays 天", Green)
            StatCard("今日完成", "$todayCount / ${workouts.size}", Brown)
        }
        Text("每项运动累计天数", modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp), fontWeight = FontWeight.SemiBold, color = Ink)
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(workouts) { w ->
                val days = records.count { it.endsWith("|${w.id}") }
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink)
                            Text("累计 $days 天 · 今天${if ("$today|${w.id}" in records) "已打卡" else "未打卡"}", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                        IconButton(onClick = { renameTarget = w }) { Icon(Icons.Default.Edit, "修改名称", tint = Brown) }
                        Checkbox(checked = "$today|${w.id}" in records, onCheckedChange = { onToggle(w.id) })
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    renameTarget?.let { w ->
        var name by remember(w) { mutableStateOf(w.name) }
        AlertDialog(onDismissRequest = { renameTarget = null }, title = { Text("修改运动名称") }, text = { OutlinedTextField(name, { name = it }, label = { Text("名称") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onRename(w.id, name.trim()); renameTarget = null }) { Text("保存") } }, dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("取消") } })
    }
}

@Composable
fun RowScope.StatCard(label: String, value: String, tint: Color) {
    Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Paper)) {
        Column(Modifier.padding(15.dp)) { Text(label, color = Muted, fontSize = 12.sp); Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = tint) }
    }
}

@Composable
fun MealScreen() {
    Header("饮食建议", "早餐 · 午餐 · 晚餐")
    val meals = listOf(
        Meal("早餐", "鸡蛋 + 牛奶 + 全麦面包", 380, "2个鸡蛋、低脂牛奶、全麦面包和一份水果"),
        Meal("午餐", "鸡胸肉藜麦沙拉", 460, "鸡胸肉 + 藜麦 + 生菜 + 番茄，清淡少油"),
        Meal("晚餐", "番茄豆腐虾仁汤", 320, "番茄 + 嫩豆腐 + 虾仁 + 青菜，饱腹又清爽")
    )
    LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
        items(meals) { m ->
            CardBox {
                Text(m.type, color = Brown, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text(m.desc, color = Muted, modifier = Modifier.padding(top = 6.dp))
                    }
                    Text("${m.kcal} kcal", color = Green, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}
